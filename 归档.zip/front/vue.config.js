module.exports = {
    devServer: {
        disableHostCheck: true,
        port: 8080,
        host:"0.0.0.0"
    },
    lintOnSave: false
}